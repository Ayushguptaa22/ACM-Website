# ACM-Website
 GEU ACM Website
 
 Design process: 
 
 ◼️Simple webflow 
 
 ◼️ease of access to users
 
 ◼️animation
 
 ◼️joining form to connect with ACM chapter
 
 
 A combination of multiple CSS and Js libraries for animation and styling.
 
 No back-end, form entries are sent straight to assigned chapter mail id.
